public class Main {
    public static void main(String[] args) {

        Porta p = new Porta(new EstadoManterAberta());
        System.out.println(p.status());
        p.clicar();
        System.out.println(p.status());
        p.clicar();
        System.out.println(p.status());
        p.clicar();
        System.out.println(p.status());
        p.clicar();
        System.out.println(p.status());
        p.clicar();
        System.out.println(p.status());
        p.clicar();
        System.out.println(p.status());

    }
}