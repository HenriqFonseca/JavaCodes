public class EstadoAberta implements EstadoPorta {

    @Override
    public EstadoPorta clicar() {
        return new EstadoManterAberta();
    }

    @Override
    public String status() {
        return "Aberta";
    }

}
