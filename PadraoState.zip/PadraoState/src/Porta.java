public class Porta {

    private EstadoPorta estado;

    public Porta(EstadoPorta estado){
        this.estado =  estado;
    }

    public  void setEstado (EstadoPorta estado){
        this.estado = estado;
    }

    public void clicar(){
        setEstado(this.estado.clicar());
    }

    public String status(){
        return this.estado.status();
    }


}
