public interface  EstadoPorta {
    EstadoPorta clicar();

    String status();
}
