public class EstadoFechando implements EstadoPorta {

    @Override
    public EstadoPorta clicar() {
        return new EstadoFechada();
    }

    @Override
    public String status() {
        return "Porta fechando...";
    }
}
