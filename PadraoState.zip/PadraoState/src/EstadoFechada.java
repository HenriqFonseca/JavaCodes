public class EstadoFechada implements EstadoPorta {

    @Override
    public EstadoPorta clicar() {
        return new EstadoAbrindo();
    }

    @Override
    public String status() {
        return "Porta fechada!!";
    }
}
