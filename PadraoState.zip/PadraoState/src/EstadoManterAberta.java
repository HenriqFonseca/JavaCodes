public class EstadoManterAberta implements EstadoPorta {

    @Override
    public EstadoPorta clicar() {
        return new EstadoFechando();
    }

    @Override
    public String status() {
        return "Porta sendo mantida aberta";
    }
}
