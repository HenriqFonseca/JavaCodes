public class EstadoAbrindo implements EstadoPorta {

    @Override
    public EstadoPorta clicar() {
        return new EstadoAberta();
    }

    @Override
    public String status() {
        return "Abrindo...";
    }
}
