import static org.junit.jupiter.api.Assertions.*;

class PortaTest {

    @org.junit.jupiter.api.Test
    void setEstado() {
    }

    @org.junit.jupiter.api.Test
    void clicar() {
    }

    @org.junit.jupiter.api.Test
    void status() {
    }
}